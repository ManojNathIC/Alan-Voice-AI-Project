

title("Spreader")
intent('hello spreader', p=>  {
    p.play('(hello how may i help you )');
});

question('what is this', p =>  {
    p.play('This is an example Spreader web app with voice capabilities. (Made  by using Alan it this page such information about awarreness about upcoming technology)');
});
question('read first article', p =>  {
    p.play('Technology Based Awareness, Change the privacy of your posts and profiles.It may take a bit of research, but there will be some level of configuration available that allows you to restrict the visibility of your posts. ');
});
question('read second article', p =>  {
    p.play('Change the privacy of your posts and profiles.It may take a bit of research, but there will be some level of configuration available that allows you to restrict the visibility of your posts. Some sites allow a great deal of control over who can see your information, while others do not.');
});


intent("what (date|day) $(V is|was|will be|would be|) $(DATE) $(T next year|last year|)",
    p => {
        if (p.T.value === "last year"){
            p.DATE = p.DATE.moment.add(-1, 'Y');
        }
        else if (p.T.value === "next year"){
            p.DATE = p.DATE.moment.add(1, 'Y');
        }
        let res = p.DATE.moment.format("dddd, MMMM Do YYYY");
        p.play(`${p.DATE} ${p.V} ` + res)
    })

follow("(and|) (what|) (about|) $(DATE)",
    p => {
        let res = p.DATE.moment.format("dddd, MMMM Do YYYY");
        p.play(`${p.DATE} ` + res)
    });
intent("when (spreader|) you was made",
    p => {
        let turingBirthdate = api.moment("20200625", "YYYYMMDD");
        p.play(`Spreader was made
			${turingBirthdate.fromNow()}
			on ${turingBirthdate.format("dddd, MMMM Do YYYY")}`)
    })

intent('Contact of spreader', p=>  {
    p.play('(Address:Vadodara Gujarat Phone: 00953855 Email:Team@gmail.com)');
});

intent('your mission', p=>  {
    p.play('Our Main Motive Is That Simple To Providig A Such Informative Information Awareness At Our Society Fingertip.');
});

intent('your plan', p=>  {
    p.play('Our Plan to Providing All The Awareness To Society For Getting To Know That Upcoming New Technologies Coming With The Carrying A havey Danger');
});
intent('your vision', p=>  {
    p.play('Here We mainly focus on How increasing of technology affect our society');
});

intent('Who own this website', p=>  {
    p.play('Copyright Team Sparrow. All Rights Reserved Developed & Designed byTeam Sparrow');
});
question(
    '(Why can\'t you answer my question|Why don\'t you understand)',
    'What\'s wrong (with you|)',
    'Wrong answer',
    reply(
        'Perhaps the given command hasn\'t been programmed into me yet. (I will get help and learn to answer correctly.|)',
        'I apologize I can\'t understand your given command. (I will ask the developer who made me to answer correctly next time.|)',
    ),
);